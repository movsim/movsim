/*
 * Copyright (C) 2010, 2011, 2012 by Arne Kesting, Martin Treiber, Ralph Germ, Martin Budden
 * <movsim.org@gmail.com>
 * -----------------------------------------------------------------------------------------
 * 
 * This file is part of
 * 
 * MovSim - the multi-model open-source vehicular-traffic simulator.
 * 
 * MovSim is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * MovSim is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with MovSim. If not, see <http://www.gnu.org/licenses/>
 * or <http://www.movsim.org>.
 * 
 * -----------------------------------------------------------------------------------------
 */

//JONAS

package org.movsim.simulator.vehicles.longitudinalmodel;

import java.util.Deque;
import java.util.Iterator;
import java.util.LinkedList;

import org.movsim.simulator.MovsimConstants;
import org.movsim.simulator.roadnetwork.RoadSegment;
//import org.movsim.simulator.roadnetwork.controller.TrafficLight
import org.movsim.simulator.roadnetwork.controller.RoadSign;

import org.movsim.simulator.vehicles.Vehicle;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.base.Preconditions;

/**
 * The class StopSignApproaching.
 * 
 */
public class StopSignApproaching {
	
	private static final double MIN_WAITING_TIME = 0.5;

    private static final Logger LOG = LoggerFactory.getLogger(StopSignApproaching.class);
    //private static final Logger LOG = LoggerFactory.getLogger(StopSignApproaching.class);
    
    // order of stop signs given by signal points
    private Deque<RoadSign> stopSigns = new LinkedList<>();

    private boolean considerStopSign;

    private double accStopSign;

    private double distanceToStopSign;
    
    private double waitingTime;
    

    
    /**
     * Instantiates a new stop sign approaching.
     */
    public StopSignApproaching() {
        considerStopSign = false;
        distanceToStopSign = MovsimConstants.INVALID_GAP;
        waitingTime = 0;
    }

    public void addStopSign(RoadSign stopSign) {
        Preconditions.checkNotNull(stopSigns);
        assert !alreadyAdded(stopSign); // check not necessarily needed
        stopSigns.add(stopSign);
        LOG.debug("vehicle: stopSignSizeSize={}, added stop sign={}", stopSigns.size(), stopSign);
    }

    private boolean alreadyAdded(RoadSign stopSignToAdd) {
        for (RoadSign stopSign : stopSigns) {
            if (stopSignToAdd == stopSigns) {
                return true;
            }
        }
        return false;
    }

    /**
     * Update.
     * 
     * @param vehicle
     */
    public void update(double dt, Vehicle vehicle, RoadSegment roadSegment) {
        reset();
        removePassedStopSigns(vehicle, roadSegment);

        RoadSign stopSign = findStopSign(vehicle, roadSegment);
        if (stopSign == null) {
            return;
        }
        distanceToStopSign = stopSign.distanceTo(vehicle, roadSegment, RoadSign.MAX_LOOK_AHEAD_DISTANCE);
//        LOG.info("approaching stop sign: distanceToStopSign={},speed={}, stopSigns={}", distanceToStopSign, vehicle.getSpeed(), toString());
        Preconditions.checkArgument(distanceToStopSign >= 0,
                        "stop sign already passed, removal of passed lights not working! [check if vehicle has passed start-signal]");

        accStopSign = calcAccelerationToStopSign(vehicle, distanceToStopSign);
        if (accStopSign < 0) {
            considerStopSign = true;


//        } else if (stopSign.status() == StopSignStatus.RED) {
//            final double maxDeceleration = vehicle.getMaxDeceleration();
//            final double minBrakeDist = (vehicle.getSpeed() * vehicle.getSpeed()) / (2 * maxDeceleration);
//            if (accStopSign <= -maxDeceleration || minBrakeDist >= distanceToStopSign) {
//                // ignore traffic light
//                LOG.info(String
//                        .format("veh id=%d in dilemma zone is going to pass red light at distance=%.2fm due to physics (assuming user-defined max. possible braking=%.2fm/s^2!",
//                                vehicle.getId(), distanceToStopSign, maxDeceleration));
//                considerStopSign = false;
//            }
            
        }
        
        /*Vehicle is considered to be waiting in front of stop sign if it's speed ist < 0.1 [m/s]
        and the distance to  the stop sign is less than minimal gap plus a tolerance of 10% */
//        if(vehicle.getSpeed() < 0.3 && distanceToStopSign <= (vehicle.getLongitudinalModel().getMinimumGap() * 1.2 )) {
      
        
        
    	if(vehicle.getSpeed() <= stopSign.getMaxV() && distanceToStopSign <= stopSign.getDecisionDistance()) { //JONAS Ändern! //JONAS TEMP maxV
    		vehicle.getYielding().addYieldSign(stopSigns.getFirst());
    		stopSigns.removeFirst(); //JONAS mit remove vereinen?
//    		LOG.info("Position at removal of stop sign={}", vehicle.getFrontPosition() );
//    		LOG.info("Stop Sign removed.");
//        	LOG.info("Wartend");
//        	if (waitingTime < MIN_WAITING_TIME){
//        		waitingTime += dt;
//        		considerStopSign = true;
////        		LOG.info("WaitingTime=",  waitingTime );
//        	} else {
//        		vehicle.getYielding().addYieldSign(stopSigns.getFirst());
//        		waitingTime=0;
//        		stopSigns.removeFirst(); //JONAS mit remove vereinen?
//        		LOG.info("Stop Sign removed.");
//        	}
        
        } //else {
//        	waitingTime = 0; //JONAS überlegen was hiermit machen
//        }
    }

    private RoadSign findStopSign(Vehicle vehicle, RoadSegment roadSegment) {
        RoadSign stopSign = null;
        Iterator<RoadSign> iterator = stopSigns.iterator();
        while (iterator.hasNext()) {
            stopSign = iterator.next();
            LOG.debug("stop sign={}", stopSign);
            return stopSign;
        }
        return null;
    }

    private void removePassedStopSigns(Vehicle vehicle, RoadSegment roadSegment) {
        for (Iterator<RoadSign> iterator = stopSigns.iterator(); iterator.hasNext();) {
            RoadSign stopSign = iterator.next();
            double distance = stopSign.distanceTo(vehicle, roadSegment, RoadSign.MAX_LOOK_AHEAD_DISTANCE);
            if (!Double.isNaN(distance) && distance < 0) {
                LOG.debug("vehicle at pos={}, remove stopSign={}", vehicle.getFrontPosition(), stopSign);
                iterator.remove();
            } else {
                return; // skip loop since stop signs are ordered
            }
        }
    }

    private void reset() {
        accStopSign = 0;
        considerStopSign = false;
        distanceToStopSign = MovsimConstants.GAP_INFINITY;
    }

    private static double calcAccelerationToStopSign(Vehicle me, double distanceToStopSign) {
        final double speed = me.getSpeed();
        return Math.min(0, me.getLongitudinalModel().calcAccSimpleStop(distanceToStopSign, speed, speed));
    }

    /**
     * Consider stop sign.
     * 
     * @return true, if successful
     */
    public boolean considerStopSign() {
        return considerStopSign;
    }

    /**
     * Acc approaching.
     * 
     * @return the double
     */
    public double accApproaching() {
        return accStopSign;
    }

    /**
     * Gets the distance to stop sign.
     * 
     * @return the distance to trafficlight
     */
    public double getDistanceToTrafficlight() {
        return distanceToStopSign;
    }

//    private static double calcEffectiveFrontVehicleLengths(Vehicle me, RoadSign stopSigns,
//            double distanceToSecondStopSign) {
//        double sumEffectiveLengths = 0;
//        Vehicle frontVehicle = stopSigns.roadSegment().laneSegment(me.lane()).frontVehicle(me);
//        while (frontVehicle != null && me.getBrutDistance(frontVehicle) < distanceToSecondStopSign) {
//            sumEffectiveLengths += frontVehicle.getEffectiveLength();
//            Vehicle prevFront = frontVehicle;
//            frontVehicle = stopSigns.roadSegment().laneSegment(frontVehicle.lane()).frontVehicle(frontVehicle);
//            if (frontVehicle != null && prevFront.getId() == frontVehicle.getId()) {
//                // FIXME seems to be a real bug: get back the *same* vehicle when its entered the downstream roadsegment
//                break;
//            }
//        }
//        return sumEffectiveLengths;
//    }

    @Override
    public String toString() {
        return "StopSignApproaching [stopSigns.size=" + stopSigns.size() + ", considerStopSign="
                + considerStopSign + ", accStopSign=" + accStopSign + ", distanceToStopSign="
                + distanceToStopSign + "]";
    }

    /**
     * Returns this vehicle's acceleration considering the traffic light.
     * 
     * @param roadSegment
     * 
     * @return acceleration considering traffic light or NaN if no traffic light is present
     */
    public double accelerationConsideringStopSign(double dt, Vehicle vehicle, RoadSegment roadSegment) {
        update(dt, vehicle, roadSegment);
        if (considerStopSign()) {
        	double acc = accApproaching();
//        	LOG.info("waitingTime={},accApproaching={}", waitingTime, acc);
        	return acc;
//            return accApproaching();
        }
        return Double.NaN;
    }
}