/*
 * Copyright (C) 2010, 2011, 2012 by Arne Kesting, Martin Treiber, Ralph Germ, Martin Budden
 * <movsim.org@gmail.com>
 * -----------------------------------------------------------------------------------------
 * 
 * This file is part of
 * 
 * MovSim - the multi-model open-source vehicular-traffic simulator.
 * 
 * MovSim is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * MovSim is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with MovSim. If not, see <http://www.gnu.org/licenses/>
 * or <http://www.movsim.org>.
 * 
 * -----------------------------------------------------------------------------------------
 */

//JONAS
package org.movsim.simulator.roadnetwork.controller;

import com.google.common.base.Preconditions;
import com.google.common.collect.Sets;

import org.movsim.simulator.roadnetwork.controller.RoadSignPriorityRoad;

import org.movsim.autogen.TrafficLightStatus;
import org.movsim.network.autogen.opendrive.OpenDRIVE;
import org.movsim.network.autogen.opendrive.OpenDRIVE.Road.Signs.Sign;
import org.movsim.simulator.roadnetwork.LaneSegment;
import org.movsim.simulator.roadnetwork.controller.RoadSignPriorityRoad;
import org.movsim.simulator.roadnetwork.RoadSegment;
import org.movsim.simulator.roadnetwork.SignalPoint;
import org.movsim.simulator.roadnetwork.regulator.Regulator;
import org.movsim.simulator.vehicles.Vehicle;

import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import static com.google.common.base.Preconditions.checkNotNull;

/**
 * Represents a 'road sign' to which vehicles will react. The visibility range is limited to {@code MAX_LOOK_AHEAD_DISTANCE}, e.g.
 * {@literal 1000m}, or to two {@link RoadSegment}s.
 */
public class RoadSign extends RoadObjectController {
	
	private static final Logger LOG = LoggerFactory.getLogger(RoadSegment.class);
	
	//JONAS	
	//BEGRÜNDET auswählen
    public static final double MAX_LOOK_AHEAD_DISTANCE = 1000;
    private static final double DEFAULT_DECISION_DISTANCE = 3.2;
    private static final double DEFAULT_MAXV = 1.75;
	private static final double DEFAULT_MIN_TIME_GAP = 1.7;
    public enum RoadSignType {
    	STOP,
    	YIELD
    }

    
    //JONAS
    //LinkedList LinkesLinkedList deque?
    private LinkedList<RoadSignPriorityRoad> priorityRoads;

    private final Sign sign;
//    private final String signalType;
    
    private RoadSignType type;
    private double decisionDistance = DEFAULT_DECISION_DISTANCE;
    private double maxV = DEFAULT_MAXV; //JONAS TEMP maxV (einen festen Wert auswählen und direkt in StopSignApproaching eintragen !) auch aus XSD löschen | oder doch varibel lassen?
    private double minTimeGap = DEFAULT_MIN_TIME_GAP;
    private SignalPoint signalPointEnd;
    private Map<RoadSegment, SignalPoint> signalPointsBegin = new HashMap<>();

    public RoadSign(Sign sign, RoadSegment roadSegment) {
    	super(RoadObjectType.ROADSIGN, sign.getS(), roadSegment);
    	this.sign = checkNotNull(sign);
        Preconditions.checkArgument(sign.isSetId(), "id not set for sign");
        Preconditions.checkArgument(sign.isSetS(), "s not set for sign");
    	
    	
        if (sign.isSetValidity()) {
            throw new IllegalArgumentException(
                    "road sign always apply to all lanes, cannot use xodr validity information from sign id="
                            + sign.getId());
        }

        
        if (sign.isSetDecisionDistance()) {
        	decisionDistance = sign.getDecisionDistance();
        }
        
        if (sign.isSetMaxV()) {
        	 maxV = sign.getMaxV();
        }
        
        if (sign.isSetMinTimeGap()) {
       	 maxV = sign.getMinTimeGap();
        }
        
        
        priorityRoads = new LinkedList <>();
        //JONAS
        //Preconditions type usw. 
        setType();
               
        signalPointEnd = new SignalPoint(position, roadSegment);
        

    }

    private void setType() {
    	if(sign.getType().equals("stop")) {
    		type = RoadSignType.STOP;
        } else if(sign.getType().equals("yield")) {
        	type = RoadSignType.YIELD;
        } else {
        	throw new IllegalArgumentException("Sign must be either of type stop or yield but not " + sign.getType() + ". Sign=" + sign.getId());
        }
    }
    
//    private String checkTypesAndExtractSignalType() {
//        String signalType = null;
//        for (OpenDRIVE.Controller.Control control : controller.getControl()) {
//            if (!control.isSetType()) {
//                throw new IllegalArgumentException(
//                        "controller.control.type must be set in xodr for signal=" + signalId());
//            }
//            if (control.getSignalId().equals(signalId())) {
//                signalType = control.getType();
//            }
//        }
//        return signalType;
//    }

    public void addPriorityRoad(RoadSignPriorityRoad roadSignPriorityRoad) {
    	priorityRoads.add(roadSignPriorityRoad);
    	//JONAS
    	LOG.info("addedPriorityRoad. priorityRoads in LinkedList:");
    	for(RoadSignPriorityRoad priorityRoad : getPriorityRoads()) {
    		LOG.info("PriorityRoad={}", priorityRoad);
    	}
    }
    
    
    
    /**
     * Returns the id. This id is defined in the infrastructure configuration file.
     *
     * @return the label
     */
    public String signId() {
        return sign.getId();
    }

    /**
     * Returns the sign Name.
     *
     * @return the label
     */
    public String signName() {
        return sign.getName();
    }
    
    public RoadSignType getSignType() {
    	return type;
    }
    
    public Sign sign() {
        return sign;
    }
    
    public RoadSegment getRoadSegment(){
    	return roadSegment;
    }
    
    public double getPosition() {
    	return position;
    }
    
    public double getDecisionDistance() {
    	return decisionDistance;
    }
    
    public Iterable<RoadSignPriorityRoad> getPriorityRoads(){
    	return priorityRoads;
    }
    
    public double getMaxV() {
    	return maxV;
    }

	public double getMinTimeGap() {
		return minTimeGap;
	}
	

    @Override
    //TODO JONAS
    public String toString() {
        return ("Not defined");
    	/*return "TrafficLight [controllerId = " + controllerId() + ", signalId = " + signalId() + ", status=" + status
                + ", position=" + position + ", signalType=" + signalType + ", groupId = " + groupId
                + ", roadSegment.id=" + ((roadSegment == null) ? "null" : roadSegment.userId()) + "]"; */
    }

    @Override
    public void createSignalPositions() {
        // downstream signal point is on local roadSegment
        roadSegment.signalPoints().add(signalPointEnd);
        LOG.info("road sign={}", this);
        LOG.info("road sign end signal point placed at position={} on roadSegment={}.", position, roadSegment);

        // create signal points for upstream signal points on potentially other roadsegments
        double upstreamPosition = position - MAX_LOOK_AHEAD_DISTANCE;
        if (upstreamPosition >= 0 || !roadSegment.hasUpstreamConnection()) {
            upstreamPosition = Math.max(0, upstreamPosition);
            addSignalPointBegin(upstreamPosition, roadSegment);
        } else {
            // put signal points to all upstream road segments while checking recursively
            Set<RoadSegment> visitedRoadSegments = Sets.newHashSet();
            double dxToGo = MAX_LOOK_AHEAD_DISTANCE - position;
            addSignalPointsToUpstreamRoadSegments(roadSegment, dxToGo, visitedRoadSegments);
        }

        if (signalPointsBegin.isEmpty()) {
            throw new IllegalStateException("did not set any upstream signal points for traffic light=" + toString());
        }

        // add created signals to roadSegments
        for (Entry<RoadSegment, SignalPoint> entry : signalPointsBegin.entrySet()) {
            entry.getKey().signalPoints().add(entry.getValue());
        }
    }

    private void addSignalPointBegin(double upstreamPosition, RoadSegment upstreamRoadSegment) {
        SignalPoint signalPoint = new SignalPoint(upstreamPosition, upstreamRoadSegment);
        signalPointsBegin.put(upstreamRoadSegment, signalPoint);
        LOG.info("road sign signal start point placed at position={} on roadSegment={}", upstreamPosition,
                upstreamRoadSegment);
    }

    private void addSignalPointsToUpstreamRoadSegments(RoadSegment startRoadSegment, double dxToGo, Set<RoadSegment> visitedRoadSegments) {
        for (LaneSegment laneSegment : startRoadSegment.laneSegments()) {
            if (laneSegment.hasSourceLaneSegment()) {
                RoadSegment upstreamRoadSegment = laneSegment.sourceLaneSegment().roadSegment();
                if (!visitedRoadSegments.contains(upstreamRoadSegment)) {
                    visitedRoadSegments.add(upstreamRoadSegment);
                    double posSignalPoint = upstreamRoadSegment.roadLength() - dxToGo;
                    if (posSignalPoint >= 0 || !upstreamRoadSegment.hasUpstreamConnection()) {
                        addSignalPointBegin(Math.max(0, posSignalPoint), upstreamRoadSegment);
                    } else {
                        // call recursively
                        addSignalPointsToUpstreamRoadSegments(upstreamRoadSegment, -posSignalPoint,
                                visitedRoadSegments);
                    }
                }
            }
        }
    }

    @Override
    public void timeStep(double dt, double simulationTime, long iterationCount) {
        for (SignalPoint signalPoint : signalPointsBegin.values()) {
            for (Vehicle vehicle : signalPoint.passedVehicles()) {
            	if(vehicle.getRoute().roadSegmentIsInRoute(this.roadSegment)) {
                    if(type == RoadSignType.STOP) {
                    	vehicle.getStopSignApproaching().addStopSign(this);
                        LOG.debug("vehicle pos={} --> set stop sign={}", vehicle.getFrontPosition(), this);
                    } else if (type == RoadSignType.YIELD) {
                    	vehicle.getYielding().addYieldSign(this);
                        LOG.debug("vehicle pos={} --> set yield sign={}", vehicle.getFrontPosition(), this);
                    }
            	} else {
            		LOG.debug("Road sign not set. Vehicle.id={}. road sign={}. RouteName={}", vehicle.getId(),this, vehicle.getRouteName());
            	}
            	//vehicle.addroadsignsInRange(this);
            }
        }
        // Vehicle handles cleaning process for already passed trafficlights autonomously
    }


    
}
