
package org.movsim.simulator.vehicles.longitudinalmodel;

import java.util.Deque;
import java.util.Iterator;
import java.util.LinkedList;

import org.movsim.simulator.MovsimConstants;
import org.movsim.simulator.roadnetwork.RoadSegment;
import org.movsim.simulator.roadnetwork.controller.RoadSign;
import org.movsim.simulator.roadnetwork.controller.RoadSignPriorityRoad;

import org.movsim.simulator.vehicles.Vehicle;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.base.Preconditions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;



public class Yielding {
	
    private static final Logger LOG = LoggerFactory.getLogger(Yielding.class);
	
    private static final double TIME_INFINITY = 10000;
    
    private boolean considerYieldSign;
    
    private double distanceToYieldSign;
    
	private boolean considerVehicleOnPriorityRoad;
	
	private static final double SIGHT_DISTANCE = 500;
	
	private Deque<RoadSign> yieldSigns = new LinkedList<>();
	
    private double accYielding;
    	
	public Yielding() {
		considerYieldSign = false;
		considerVehicleOnPriorityRoad = false;
	}

	
    public void addYieldSign(RoadSign yieldSign) {
        Preconditions.checkNotNull(yieldSign);
        assert !alreadyAdded(yieldSign); // check not necessarily needed
        yieldSigns.add(yieldSign);
        LOG.debug("vehicle: yieldSignSize={}, added yield sign={}", yieldSigns.size(), yieldSign);
    }
    
    private boolean alreadyAdded(RoadSign yieldSignToAdd) {
        for (RoadSign yieldSign : yieldSigns) {
            if (yieldSignToAdd == yieldSigns) {
                return true;
            }
        }
        return false;
    }
    
    /**
     * Update.
     * 
     * @param vehicle
     */
    public void update(double simulationTime, Vehicle vehicle, RoadSegment roadSegment) { //JONAS tempsimtime
        reset();
        removePassedYieldSigns(vehicle, roadSegment);

        RoadSign yieldSign = findYieldSign(vehicle, roadSegment);
        if (yieldSign == null) {
            return;
        }
        
        distanceToYieldSign = yieldSign.distanceTo(vehicle, roadSegment, yieldSign.MAX_LOOK_AHEAD_DISTANCE);
        LOG.debug("approaching yield sign: distanceToYieldSign={}, stopSigns={}", distanceToYieldSign, toString());
        Preconditions.checkArgument(distanceToYieldSign >= 0, "stop sign already passed, removal of passed lights not working! [check if vehicle has passed start-signal]");
        
//        if(distanceToYieldSign < Math.max(vehicle.getS0(), yieldSign.getDecisionDistance())) { //getS0 hinzufügen. Für Modelle wo es nicht gibt umgehbar?
        if(distanceToYieldSign < yieldSign.getDecisionDistance()) {
            //double timeToIntersectionMainRoad = TIME_INFINITY;
            //Sichergehen, dass Signs nicht ohne PriorityRoads erstellt werden können
        	boolean roadClear = true;
//        	double timeNeededToPassIntersectiOnSideRoad = -1;
            for(RoadSignPriorityRoad priorityRoad : yieldSign.getPriorityRoads()) {
                Vehicle vehicleOnPriorityRoad = findVehicleOnPriorityRoad(priorityRoad.getRoadSegment(),priorityRoad.getS(),  priorityRoad.getLengthIntersection());
                //double timeNeededToPassIntersectiOnSideRoad_TEMP= calcTimeNeededToPassIntersectionOnSideRoad(vehicle, priorityRoad.getLengthIntersectionSideRoad()); //JONAS rauslöschen!
                 LOG.info("simulationTime={}",simulationTime); //JONAS rauslöschen!
                if(vehicleOnPriorityRoad != null) {
                	double timeNeededToPassIntersectiOnSideRoad= calcTimeNeededToPassIntersectionOnSideRoad(vehicle, yieldSign.getPosition(), priorityRoad.getLengthIntersectionSideRoad());
//                	LOG.info("timeNeededToPassIntersectiOnSideRoad=" + timeNeededToPassIntersectiOnSideRoad);
                	double timeToIntersectionMainRoad = calctimeToIntersectionMainRoad(vehicleOnPriorityRoad, priorityRoad.getS());
                			//yieldSign.getPosition() +20);
//    	        	LOG.info(", Side Road, " + vehicle.getId() + ", " + simulationTime + ", " + timeNeededToPassIntersectiOnSideRoad + ", " + (simulationTime + timeNeededToPassIntersectiOnSideRoad));
//    	        	LOG.info(", Main Road, " + vehicleOnPriorityRoad.getId() + ", " + simulationTime + ", " + timeToIntersectionMainRoad + ", " + (simulationTime + timeToIntersectionMainRoad));
                	LOG.info(", Side Road, " + timeNeededToPassIntersectiOnSideRoad);
    	        	LOG.info(", Main Road, " + timeToIntersectionMainRoad);
//                    LOG.info(timeToIntersectionMainRoad + " < " + timeNeededToPassIntersectiOnSideRoad + " + " + priorityRoad.getMinTimeGap() + " ?");
                	if(timeToIntersectionMainRoad < timeNeededToPassIntersectiOnSideRoad + yieldSign.getMinTimeGap())  {
//                	if(timeToIntersectionMainRoad < timeNeededToPassIntersectiOnSideRoad)  {
                		roadClear = false;
                		LOG.info("belegt");
                    	break;
                    }
                	
                	LOG.info("frei");
//                    
                    	
                }
                	
                    
                    //JONAS
                	//timeToIntersectionMainRoad = Math.min(timeToIntersectionMainRoad,;
                    //LOG.info("timeToIntersectionMainRoad={}", timeToIntersectionMainRoad);

                }
	        if(roadClear) {
	        	//LOG.info(", SimulationTime=" + simulationTime + ", VehicleId=" + vehicle.getId() + ", timeNeededToPassIntersectiOnSideRoad=" + timeNeededToPassIntersectiOnSideRoad); //JONAS tempsimtime7

	            return; 
	        }
            //JONAS getT() und getA bisher nur für ACC und IDM
//            if(timeToIntersectionMainRoad > timeNeededToPassIntersectiOnSideRoad + vehicle.getLongitudinalModel().getT()) {
//            	return;
//            }

        }
        

        accYielding = calcAccelerationYielding(vehicle, distanceToYieldSign);
        if (accYielding < 0) {
        	considerYieldSign = true;
            LOG.debug("distance to yieldSigns = {}, accTL = {}", distanceToYieldSign, accYielding);           
        }
    }
    
    private RoadSign findYieldSign(Vehicle vehicle, RoadSegment roadSegment) {
    	RoadSign yieldSign = null;
        Iterator<RoadSign> iterator = yieldSigns.iterator();
        while (iterator.hasNext()) {
        	yieldSign = iterator.next();
            LOG.debug("yield sign={}", yieldSign);
            return yieldSign;
        }
        return null;
    }
    
    
    private void removePassedYieldSigns(Vehicle vehicle, RoadSegment roadSegment) {
        for (Iterator<RoadSign> iterator = yieldSigns.iterator(); iterator.hasNext();) {
            RoadSign yieldSign = iterator.next();
            double distance = yieldSign.distanceTo(vehicle, roadSegment, RoadSign.MAX_LOOK_AHEAD_DISTANCE);
            if (!Double.isNaN(distance) && distance < 0) {
                LOG.debug("vehicle at pos={}, remove yieldSign={}", vehicle.getFrontPosition(), yieldSign);
                iterator.remove();
            } else {
                return; // skip loop since yield signs are ordered
            }
        }
    }
    
    //JONAS TODO Auch Vorgängerstraßen beachten!
    private Vehicle findVehicleOnPriorityRoad(RoadSegment priorityRoadSegment, double s, double lengthIntersection ) {
    	double sEnd = s + lengthIntersection;
    	if(sEnd > priorityRoadSegment.roadLength()) {
    		throw new IllegalArgumentException("Straße kürzer als sEnd"); //JONAS TODO auf Nachfolger Straße suchen statt Exception
    	}
        for (Iterator<Vehicle> vehIterator = priorityRoadSegment.iterator(); vehIterator.hasNext();) {
            Vehicle vehicleOnPriorityRoad = vehIterator.next();
    		if(vehicleOnPriorityRoad.getRearPosition() < sEnd && vehicleOnPriorityRoad.getRearPosition() > sEnd - SIGHT_DISTANCE ) {
    			return vehicleOnPriorityRoad;
    		}
    	}
    	return null;
    }
    
    private double calcTimeNeededToPassIntersectionOnSideRoad(Vehicle vehicle, double signPosition, double lengthIntersectionSideRoad) {
    	double distance = signPosition + lengthIntersectionSideRoad - vehicle.getRearPosition();
    	LOG.info("distanceSIdeRoad={}", distance);
		//double distance = sEndIntersection -  vehicle.getRearPosition();
		double a = vehicle.getLongitudinalModel().getA();
		double delta = vehicle.getLongitudinalModel().getDelta();
		double speed = vehicle.getSpeed();
		double desiredSpeed = vehicle.getLongitudinalModel().getDesiredSpeed();
		double vstar = Math.min(Math.sqrt(Math.pow(speed,2)+2*a*distance), desiredSpeed);
//		Preconditions.checkArgument(vstar < desiredSpeed, "Calculation of time needed to cross intersection not possible. Speed too high at the end of the intersection."); //JONAS anpassen!
//		Preconditions.checkArgument(vstar < desiredSpeed/2, "Calculation of time needed to cross intersection may be inaccurate. Speed too high at the end of the intersection. vstar=" + vstar + ", a=" + a +", distance=" + distance); 
		double astar = a*(1-Math.pow(vstar/desiredSpeed,delta)); //JONAS kann eigentlich longtitudinal-Modell übernehemn 
//		if(vstar > desiredSpeed/2){
//			LOG.debug("Calculation of time needed to cross intersection may be inaccurate. Speed too high at the end of the intersection. vstar=" + vstar + ", a*=" + astar +", distance=" + distance);
//		}
		
		//double t = Math.sqrt((2*distance)/astar);
		double t = -(speed/astar)+Math.sqrt(Math.pow(speed/astar, 2)+2*distance/astar);
//		LOG.info("VehicleId=" + vehicle.getId() + ", TimeNeededToPassIntersectionOnSideRoad=" + t + ", vstar=" + vstar + ", a*=" + astar +", distance=" + distance);
//		LOG.info("timeNeededToPassIntersectiOnSideRoad={}, distance= {}, astar={}, vstar={}",t, distance, astar, vstar);
		return t;
    }
    
    
    private double calcTimeNeededToPassIntersectionOnSideRoad_OLD(Vehicle vehicle, double sEndIntersection) {
		double distance = sEndIntersection -  vehicle.getRearPosition();
		//double acc = vehicle.getAcc();
		//JONAS BSIHER NUR ACC
		double a = vehicle.getLongitudinalModel().getA();
		double speed = vehicle.getSpeed();
		double desiredSpeed = vehicle.getLongitudinalModel().getDesiredSpeed();
		double timeConstantAcceleartion = -(speed/a)+Math.sqrt(Math.pow(speed/a, 2)+2/a*distance);
		double timeToReachDesiredSpeed = (desiredSpeed - speed)/a;
//		LOG.info("a={}", a);
		if(timeConstantAcceleartion >  timeToReachDesiredSpeed) {
			double distanceAccelerating = a * 0.5 * a * timeToReachDesiredSpeed + speed * timeToReachDesiredSpeed;
			return timeToReachDesiredSpeed + (distance-distanceAccelerating)/desiredSpeed;
		} else {
			return timeConstantAcceleartion;
		}
    	
    }
    
    
    private double calctimeToIntersectionMainRoad(Vehicle vehicle, double sStart) {
		if(vehicle.getSpeed() == 0) {
			return TIME_INFINITY;
		}
		
		//JONAS
		//Mehrere RoadSegments ermöglichen
		double distance = sStart -  vehicle.getFrontPosition();
		
		if (distance <= 0){
			return 0;
		}
		
		double acc = vehicle.getAcc();
		double speed = vehicle.getSpeed();
		
		LOG.info("acc={}", acc);
		LOG.info("distance={}", distance);
		
		//when acceleration is negative or zero constant speed is assumed as real world driver would do for security reasons
		if(acc <= 0.001) {
			
			LOG.info("acc<=0.01");
			return distance / speed;
		}
		LOG.info("acc>0.01");
		double desiredSpeed = vehicle.getLongitudinalModel().getDesiredSpeed(); //JONAS berücksichtigt Speedlimits?
		double timeNeeded = - (speed/acc)+Math.sqrt(Math.pow(speed/acc, 2)+2/acc*distance);
		double timeToReachDesiredSpeed = (desiredSpeed - speed)/acc;
		if(timeNeeded >  timeToReachDesiredSpeed) {
			double distanceAccelerating =0.5 * acc * Math.pow(timeToReachDesiredSpeed, 2) + speed * timeToReachDesiredSpeed;
			timeNeeded = timeToReachDesiredSpeed + (distance-distanceAccelerating)/desiredSpeed;
		}
		
		return timeNeeded;

		
    }
    
    private void reset() {
        accYielding = 0;
        considerYieldSign = false;
        //JONAS
        distanceToYieldSign = MovsimConstants.GAP_INFINITY;
    }
    
    private static double calcAccelerationYielding(Vehicle me, double distanceToYieldSign) {
        final double speed = me.getSpeed();
        return Math.min(0, me.getLongitudinalModel().calcAccSimpleStop(distanceToYieldSign, speed, speed));
    }
       
    /**
     * Consider traffic light.
     * 
     * @return true, if successful
     */
    public boolean considerYieldSign() {
        return considerYieldSign;
    }
    
    /**
     * Acc yielding.
     * 
     * @return the double
     */
    public double accYielding() {
        return accYielding;
    }
    
    //JONAS
    //TODO
//    @Override
//    public String toString() {
//        return "StopSignApproaching [yieldSigns.size=" + yieldSigns.size() + ", considerStopSign="
//                + considerStopSign + ", accStopSign=" + accStopSign + ", distanceToStopSign="
//                + distanceToStopSign + "]";
//    }
    
    
    public double accelerationYielding(double simulationTime, Vehicle vehicle, RoadSegment roadSegment) {  //JONAS tempsimtime
        update(simulationTime, vehicle, roadSegment);  //JONAS tempsimtime
        if (considerYieldSign()) {
            return accYielding();
        }
        return Double.NaN;
    }
    
    
}
