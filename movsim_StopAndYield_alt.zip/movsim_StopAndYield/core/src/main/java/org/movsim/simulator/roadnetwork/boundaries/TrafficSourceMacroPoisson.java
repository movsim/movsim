/*
 * Copyright (C) 2010, 2011, 2012 by Arne Kesting, Martin Treiber, Ralph Germ, Martin Budden
 * <movsim.org@gmail.com>
 * //JONAS Poisson 
 * -----------------------------------------------------------------------------------------
 * 
 * This file is part of
 * 
 * MovSim - the multi-model open-source vehicular-traffic simulator.
 * 
 * MovSim is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * MovSim is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with MovSim. If not, see <http://www.gnu.org/licenses/>
 * or <http://www.movsim.org>.
 * 
 * -----------------------------------------------------------------------------------------
 */

package org.movsim.simulator.roadnetwork.boundaries;

import org.movsim.simulator.roadnetwork.LaneSegment;
import org.movsim.simulator.roadnetwork.RoadSegment;
import org.movsim.simulator.vehicles.TestVehicle;
import org.movsim.simulator.vehicles.TrafficCompositionGenerator;
import org.movsim.simulator.vehicles.Vehicle;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class TrafficSourceMacroPoisson extends AbstractTrafficSourceMacro {

    private static final Logger LOG = LoggerFactory.getLogger(TrafficSourceMacroPoisson.class);
    
    private double nextArrivalInterval;

    private int vehiclesWaiting;

    /**
     * Instantiates a new upstream boundary .
     *
     * @param vehGenerator the vehicle generator
     */
    public TrafficSourceMacroPoisson(TrafficCompositionGenerator vehGenerator, RoadSegment roadSegment,
            InflowTimeSeries inflowTimeSeries) {
        super(vehGenerator, roadSegment, inflowTimeSeries);
//        this.inflowTimeSeries = inflowTimeSeries;
    }

    @Override
    public void timeStep(double dt, double simulationTime, long iterationCount) {
        final double totalInflow = (getTotalInflow(simulationTime));
        nWait += dt;

        calcApproximateInflow(dt);

        if (vehiclesWaiting > 0) {
            boolean isEntered = insertAtInflow(totalInflow, simulationTime);
            if (isEntered) {
                removeWaitingVehicle();
                return; // only one insert per simulation update
            }
        }

        if (nWait >= nextArrivalInterval) {
            nWait = 0;
            nextArrivalInterval = getPoissonInterarrivalDelay(totalInflow);
            boolean isEntered = insertAtInflow(totalInflow, simulationTime);
            if (isEntered) {
                return; // only one insert per simulation update
            }

            // haven't entered a vehicle, add to wait queue
            addWaitingVehicle();
        }
    }
    
    private boolean insertAtInflow(double totalInflow, double simulationTime) {
        if (testVehicle == null) {
            testVehicle = vehGenerator.getTestVehicle();
        }

        // try to insert new vehicle at inflow, iterate periodically over n lanes
        int iLane = laneEnterLast;
        for (int i = 0, N = roadSegment.laneCount(); i < N; i++) {
            iLane = getNewCyclicLaneForEntering(iLane);
            final LaneSegment laneSegment = roadSegment.laneSegment(iLane);
            // laneIndex index is identical to vehicle's lanenumber
            // type of new vehicle
            final boolean isEntered = tryEnteringNewVehicle(testVehicle, laneSegment, simulationTime, totalInflow);
            if (isEntered) {
                testVehicle = null;
                incrementInflowCount(1);
                recordData(simulationTime, totalInflow);
                return true;
            }
        }
        return false;
    }
    
    private double getPoissonInterarrivalDelay(double lambda) {
        return (Math.log(1.0 - Math.random()) / -lambda);
    }

    private void addWaitingVehicle() {
        vehiclesWaiting += 1;
    }

    private void removeWaitingVehicle() {
        vehiclesWaiting -= 1;
        if (vehiclesWaiting < 0) {
            vehiclesWaiting = 0;
        }
    }

//    public int getVehiclesWaiting() {
//        return vehiclesWaiting;
//    }
  

}
