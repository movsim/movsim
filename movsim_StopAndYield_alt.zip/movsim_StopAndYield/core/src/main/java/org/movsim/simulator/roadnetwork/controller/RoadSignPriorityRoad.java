/*
 * Copyright (C) 2010, 2011, 2012 by Arne Kesting, Martin Treiber, Ralph Germ, Martin Budden
 * <movsim.org@gmail.com>
 * -----------------------------------------------------------------------------------------
 * 
 * This file is part of
 * 
 * MovSim - the multi-model open-source vehicular-traffic simulator.
 * 
 * MovSim is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * MovSim is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with MovSim. If not, see <http://www.gnu.org/licenses/>
 * or <http://www.movsim.org>.
 * 
 * -----------------------------------------------------------------------------------------
 */

//JONAS
package org.movsim.simulator.roadnetwork.controller;

import com.google.common.base.Preconditions;
import com.google.common.collect.Sets;
import org.movsim.autogen.TrafficLightStatus;
import org.movsim.network.autogen.opendrive.OpenDRIVE;
import org.movsim.network.autogen.opendrive.OpenDRIVE.Road.Signs.Sign;
import org.movsim.network.autogen.opendrive.OpenDRIVE.Road.Signs.Sign.PriorityRoads.PriorityRoad;
import org.movsim.simulator.roadnetwork.LaneSegment;
import org.movsim.simulator.roadnetwork.RoadSegment;
import org.movsim.simulator.roadnetwork.SignalPoint;
import org.movsim.simulator.roadnetwork.regulator.Regulator;
import org.movsim.simulator.vehicles.Vehicle;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import static com.google.common.base.Preconditions.checkNotNull;

/**
 * Represents a 'road sign' to which vehicles will react. The visibility range is limited to {@code MAX_LOOK_AHEAD_DISTANCE}, e.g.
 * {@literal 1000m}, or to two {@link RoadSegment}s.
 */
public class RoadSignPriorityRoad{
	
	RoadSegment roadSegment;
	double s; //JONAS TODO überhaupt notwendig? ja
	double lengthIntersection;
	double lengthIntersectionSideRoad;

	double minTimeGap;
	
	public RoadSignPriorityRoad(RoadSegment roadSegment, PriorityRoad priorityRoad){
		Preconditions.checkArgument(priorityRoad.isSetSPriorityRoad(), "sPriorityRoad not set");
		Preconditions.checkArgument(s >= 0 && s <= roadSegment.roadLength(), "cannot create priorityRoad at invalid s=" + s);
		Preconditions.checkArgument(priorityRoad.isSetLengthIntersection(), "lengthIntersection not set");
		Preconditions.checkArgument(priorityRoad.isSetLengthIntersectionSideRoad(), "lengthIntersectionSideRoad not set");
		
		this.roadSegment =  roadSegment;
		s = priorityRoad.getSPriorityRoad();
		lengthIntersection = priorityRoad.getLengthIntersection();
		lengthIntersectionSideRoad = priorityRoad.getLengthIntersectionSideRoad();
//		if (priorityRoad.isSetMinTimeGap()) {
//			minTimeGap = priorityRoad.getMinTimeGap();
//		} else {
//			minTimeGap = 1.7;
//		}
			//JONAS  evtl Ausgabe mit Hinweis, das auf Default gesetzt		}
		
	}
	
	public RoadSegment getRoadSegment() {
		return roadSegment;
	}
	
	public double getS() {
		return s;
	}
	
	public double getLengthIntersectionSideRoad() {
		return lengthIntersectionSideRoad;
	}
	
	public double getLengthIntersection() {
		return lengthIntersection;
	}

	public double getMinTimeGap() {
		return minTimeGap;
	}
	
    public String toString() {
    	return "PriorityRoad [roadSegment.id=" + ((roadSegment == null) ? "null" : roadSegment.userId()) + ", S = " + s + "]";
    }
}
