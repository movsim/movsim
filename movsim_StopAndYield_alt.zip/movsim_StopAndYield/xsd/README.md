MovsimXsd
=========

MovSim = **M**ulti-model **o**pen-source **v**ehicular-traffic **Sim**ulator.

http://www.movsim.org


Description
-----------

The `MovsimXsd` submodule contains xsd schema resources for autogenerating classes with jaxb. 


Installation
------------

For installation see the [README.md](https://github.com/movsim/movsim/blob/develop/README.md) in the main MovSim directory.


Commercial use
--------------

For commercial use, please contact the copyright holders at movsim@akesting.de


Copyright
---------

MovSim is Copyright (C) 2010-2016 by Arne Kesting, Martin Treiber, Ralph Germ, and Martin Budden.

MovSim is licensed under [GPL version 3](https://github.com/movsim/movsim/blob/develop/COPYING).

