package org.movsim.simulator.vehicles.longitudinalmodel.acceleration.parameter;

/**
 *
 */
// TODO documentation like in IModelParameterIDM
public interface IModelParameterNSM extends IModelParameter {

    double getPSlowStart();

    double getPSlowdown();

}
