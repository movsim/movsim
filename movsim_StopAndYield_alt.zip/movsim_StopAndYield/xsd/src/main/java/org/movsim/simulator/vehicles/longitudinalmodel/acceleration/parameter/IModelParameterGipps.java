package org.movsim.simulator.vehicles.longitudinalmodel.acceleration.parameter;

/**
 * 
 */
// TODO documentation like in IModelParameterIDM
public interface IModelParameterGipps extends IModelParameter {

    double getA();

    double getB();

}
