package org.movsim.simulator.vehicles.longitudinalmodel.acceleration.parameter;

/**
 *
 */
// TODO documentation like in IModelParameterIDM
public interface IModelParameterNewell extends IModelParameter {

}
