/*
 * Copyright (C) 2010, 2011, 2012 by Arne Kesting, Martin Treiber, Ralph Germ, Martin Budden
 * <movsim.org@gmail.com>
 * -----------------------------------------------------------------------------------------
 * 
 * This file is part of
 * 
 * MovSim - the multi-model open-source vehicular-traffic simulator.
 * 
 * MovSim is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * MovSim is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with MovSim. If not, see <http://www.gnu.org/licenses/>
 * or <http://www.movsim.org>.
 * 
 * -----------------------------------------------------------------------------------------
 */

//JONAS
package org.movsim.simulator.roadnetwork.controller;

import com.google.common.base.Preconditions;
import com.google.common.collect.Sets;
import org.movsim.autogen.TrafficLightStatus;
import org.movsim.network.autogen.opendrive.OpenDRIVE;
import org.movsim.network.autogen.opendrive.OpenDRIVE.Road.Signs.Sign;
import org.movsim.simulator.roadnetwork.LaneSegment;
import org.movsim.simulator.roadnetwork.RoadSegment;
import org.movsim.simulator.roadnetwork.SignalPoint;
import org.movsim.simulator.roadnetwork.regulator.Regulator;
import org.movsim.simulator.vehicles.Vehicle;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import static com.google.common.base.Preconditions.checkNotNull;

/**
 * Represents a 'yield sign' to which vehicles will react. The visibility range is limited to {@code MAX_LOOK_AHEAD_DISTANCE}, e.g.
 * {@literal 1000m}, or to two {@link RoadSegment}s.
 */
public class YieldSign extends RoadObjectController {
	
	//JONAS
	//BEGRÜNDET auswählen
    public static final double MAX_LOOK_AHEAD_DISTANCE = 500;

    private final Sign sign;
//    private final String signalType;

    private final SignalPoint signalPointEnd;
    private final Map<RoadSegment, SignalPoint> signalPointsBegin = new HashMap<>();

    public YieldSign(Sign sign, RoadSegment roadSegment) {
        super(RoadObjectType.YIELDSIGN, sign.getS(), roadSegment);
        if (sign.isSetValidity()) {
            throw new IllegalArgumentException(
                    "yield sign always apply to all lanes, cannot use xodr validity information from sign id="
                            + sign.getId());
        }
        this.sign = checkNotNull(sign);
        Preconditions.checkArgument(sign.isSetId(), "id not set");
        Preconditions.checkArgument(!sign.getId().isEmpty(), "empty id!");
        Preconditions.checkArgument(sign.isSetS(), "sign.s not set");
//        this.signalType = checkNotNull(checkTypesAndExtractSignalType());  // TODO fix sonar
        signalPointEnd = new SignalPoint(position, roadSegment);
    }

//    private String checkTypesAndExtractSignalType() {
//        String signalType = null;
//        for (OpenDRIVE.Controller.Control control : controller.getControl()) {
//            if (!control.isSetType()) {
//                throw new IllegalArgumentException(
//                        "controller.control.type must be set in xodr for signal=" + signalId());
//            }
//            if (control.getSignalId().equals(signalId())) {
//                signalType = control.getType();
//            }
//        }
//        return signalType;
//    }

    /**
     * Returns the id. This id is defined in the infrastructure configuration file.
     *
     * @return the label
     */
    public String signId() {
        return sign.getId();
    }

    /**
     * Returns the sign Name.
     *
     * @return the label
     */
    public String signName() {
        return sign.getName();
    }
    

    public Sign sign() {
        return sign;
    }


    
    

    @Override
    //TODO
    public String toString() {
        return ("Not defined");
    	/*return "TrafficLight [controllerId = " + controllerId() + ", signalId = " + signalId() + ", status=" + status
                + ", position=" + position + ", signalType=" + signalType + ", groupId = " + groupId
                + ", roadSegment.id=" + ((roadSegment == null) ? "null" : roadSegment.userId()) + "]"; */
    }

    @Override
    public void createSignalPositions() {
        // downstream signal point is on local roadSegment
        roadSegment.signalPoints().add(signalPointEnd);
        LOG.info("yield sign={}", this);
        LOG.info("yield sign end signal point placed at position={} on roadSegment={}.", position, roadSegment);

        // create signal points for upstream signal points on potentially other roadsegments
        double upstreamPosition = position - MAX_LOOK_AHEAD_DISTANCE;
        if (upstreamPosition >= 0 || !roadSegment.hasUpstreamConnection()) {
            upstreamPosition = Math.max(0, upstreamPosition);
            addSignalPointBegin(upstreamPosition, roadSegment);
        } else {
            // put signal points to all upstream road segments while checking recursively
            Set<RoadSegment> visitedRoadSegments = Sets.newHashSet();
            double dxToGo = MAX_LOOK_AHEAD_DISTANCE - position;
            addSignalPointsToUpstreamRoadSegments(roadSegment, dxToGo, visitedRoadSegments);
        }

        if (signalPointsBegin.isEmpty()) {
            throw new IllegalStateException("did not set any upstream signal points for traffic light=" + toString());
        }

        // add created signals to roadSegments
        for (Entry<RoadSegment, SignalPoint> entry : signalPointsBegin.entrySet()) {
            entry.getKey().signalPoints().add(entry.getValue());
        }
    }

    private void addSignalPointBegin(double upstreamPosition, RoadSegment upstreamRoadSegment) {
        SignalPoint signalPoint = new SignalPoint(upstreamPosition, upstreamRoadSegment);
        signalPointsBegin.put(upstreamRoadSegment, signalPoint);
        LOG.info("yield sign signal start point placed at position={} on roadSegment={}", upstreamPosition,
                upstreamRoadSegment);
    }

    private void addSignalPointsToUpstreamRoadSegments(RoadSegment startRoadSegment, double dxToGo, Set<RoadSegment> visitedRoadSegments) {
        for (LaneSegment laneSegment : startRoadSegment.laneSegments()) {
            if (laneSegment.hasSourceLaneSegment()) {
                RoadSegment upstreamRoadSegment = laneSegment.sourceLaneSegment().roadSegment();
                if (!visitedRoadSegments.contains(upstreamRoadSegment)) {
                    visitedRoadSegments.add(upstreamRoadSegment);
                    double posSignalPoint = upstreamRoadSegment.roadLength() - dxToGo;
                    if (posSignalPoint >= 0 || !upstreamRoadSegment.hasUpstreamConnection()) {
                        addSignalPointBegin(Math.max(0, posSignalPoint), upstreamRoadSegment);
                    } else {
                        // call recursively
                        addSignalPointsToUpstreamRoadSegments(upstreamRoadSegment, -posSignalPoint,
                                visitedRoadSegments);
                    }
                }
            }
        }
    }

    @Override
    public void timeStep(double dt, double simulationTime, long iterationCount) {
        for (SignalPoint signalPoint : signalPointsBegin.values()) {
            for (Vehicle vehicle : signalPoint.passedVehicles()) {
            	if(vehicle.getRoute().roadSegmentIsInRoute(this.roadSegment)) {
                    //TODO
            		//vehicle.getStopSignApproaching().addStopSign(this);
                    LOG.debug("vehicle pos={} --> set yield sign={}", vehicle.getFrontPosition(), this);
            	} else {
            		LOG.debug("yield sign not set. Vehicle.id={}. yield sign={}. RouteName={}", vehicle.getId(),this, vehicle.getRouteName());
            	}
            	//vehicle.addStopSignsInRange(this);
            }
        }
        // Vehicle handles cleaning process for already passed trafficlights autonomously
    }

    public RoadSegment getRoadSegment(){
    	return roadSegment;
    }
    
}
